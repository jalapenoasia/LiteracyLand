using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bushes : MonoBehaviour
{
    public List<GameObject> Bushes;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void resetBushes(){
        for(int i = 0; i < Bushes.Count; i++){
            if(GameObject.Find(Bushes[i].name) == null){
            Instantiate(Bushes[i], Bushes[i].transform.position, Quaternion.identity);}
        }
    }
}
