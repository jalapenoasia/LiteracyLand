using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Firebase;
using Firebase.Database;


public class ClassCodeManager : MonoBehaviour
{
   
//    public TMP_InputField classcode;
//    public TMP_InputField username;
   public string name;
   public string code;
   public static ClassCodeManager instance = null;
    private DatabaseReference dbReference;
    public string deckName;
    public bool teacher;
    public string key;
    public GameObject title;
    private bool start;
    public List<string> answers;
    public List<string> problems;


    void Awake()
{
         dbReference = FirebaseDatabase.DefaultInstance.RootReference;
         if(start == false){
        title.SetActive(true);
         } else {
            title.SetActive(false);
         }
   if(instance == null)
   {
       instance = this;
       DontDestroyOnLoad(gameObject); 
   }
   else
   {
       Destroy(gameObject);
   }
}
public void Teacher1()
{
    name = "Teacher1";
code = "111";
teacher = true;
}

public void Teacher2(){
     name = "Teacher2";
    code = "000";
    teacher = true;
}

    public void Jane(){
        
        name = "Jane";
        code = "000";
        teacher = false;
        //go to next scene
    
    }
    public void John(){
        name = "John";
        code = "111";
        teacher = false;
        //go to next scene
    }

    public void closeTitle(){
        title.SetActive(false);
        start = true;
    }
}
