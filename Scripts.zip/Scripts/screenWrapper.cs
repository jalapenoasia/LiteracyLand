using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class screenWrapper : MonoBehaviour
{
    private float leftBoundary = Screen.width;
    private float rightBoundary = Screen.width;
    private float bottomBoundary = Screen.height;
    private float topBoundary = Screen.height;
    public float buffer = 4.0f;
    private float distanceZ;
    private Camera cam;
    public float reset;


    void Start()
    {
        cam = Camera.main;
        leftBoundary = cam.ScreenToWorldPoint(new Vector2(0.0f, 0.0f)).x;
        rightBoundary = cam.ScreenToWorldPoint(new Vector2(Screen.width, 0.0f)).x;
        bottomBoundary = cam.ScreenToWorldPoint(new Vector2(0.0f, 0.0f)).y;
        topBoundary = cam.ScreenToWorldPoint(new Vector2( 0.0f, Screen.height)).y;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(transform.position.x < leftBoundary - buffer){
            transform.position = new Vector3(rightBoundary + reset, transform.position.y, transform.position.z);
        }

        // if(transform.position.x > rightBoundary){
        //     transform.position = new Vector3(rightBoundary, transform.position.y, transform.position.z);
        // }
   
    }

    void Update(){
        float speed = 2f;
        transform.Translate(Vector2.left * speed * Time.deltaTime);
    }







    
}
