using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XP : MonoBehaviour
{
   public int xp;

  public XP(int xp){
        this.xp = xp;
  }
}
