using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Firebase;
using Firebase.Database;
using System.Threading.Tasks;

public class RegionManager : MonoBehaviour
{
    public static RegionManager instance;
    public List<string> problems;
    public List<string> answers;
    public static int n;
    public static int an;
    public static string answer;
    public static string problem;
    public TextMeshProUGUI text;
    public List<TextMeshProUGUI> clickedObjects = new List<TextMeshProUGUI>();
    private DatabaseReference dbReference;
    public string key;
    private DataSnapshot keysnapshot;
    public static int answerCount;
    public GameObject HSHandler;
    public int ln; //listnumber
    public GameObject Celebratory;
    public static bool celebrate;
    

    
  

   public async void Start()
    {
        Celebratory.SetActive(false);
        celebrate = false;
        
        HSHandler = GameObject.Find("HSManager");

    //    dbReference = FirebaseDatabase.DefaultInstance.RootReference;
    // await GetKey();
    for(int i = 0; i < HSHandler.GetComponent<ClassCodeManager>().answers.Count; i++){
        answers.Add(HSHandler.GetComponent<ClassCodeManager>().answers[ln]);
        problems.Add(HSHandler.GetComponent<ClassCodeManager>().problems[ln]);
        ln++;
    }
    problem = problems[n];
        text.text = problem;
        if(clickedObjects.Count == 3){
        clickedObjects[0].GetComponent<TextMeshProUGUI>().text = answers[an];
    clickedObjects[1].GetComponent<TextMeshProUGUI>().text = answers[an+1];
    clickedObjects[2].GetComponent<TextMeshProUGUI>().text = answers[an+2];
    clickedObjects.Shuffle(3);} else{
        clickedObjects[0].GetComponent<TextMeshProUGUI>().text = answers[an];
    clickedObjects[1].GetComponent<TextMeshProUGUI>().text = answers[an+1];
    clickedObjects.Shuffle(2);

    
    }

    answerCount = answers.Count;
    }

void Update(){
    if (celebrate == true){
            Celebratory.SetActive(true);
        }

if(celebrate == false){
        answer = answers[n];
        problem = problems[n];
        text.text = problem;}
  }      

        

public void advance(){
    Debug.Log(n.ToString() + " # its on");

     if(clickedObjects.Count == 3){
        clickedObjects[0].GetComponent<TextMeshProUGUI>().text = answers[an];
    clickedObjects[1].GetComponent<TextMeshProUGUI>().text = answers[an+1];
    clickedObjects[2].GetComponent<TextMeshProUGUI>().text = answers[an+2];
    clickedObjects.Shuffle(3);} else{
        clickedObjects[0].GetComponent<TextMeshProUGUI>().text = answers[an];
    clickedObjects[1].GetComponent<TextMeshProUGUI>().text = answers[an+1];
    clickedObjects.Shuffle(2);
    }
}


// public async Task GetKey(){
//    await dbReference.Child("words").GetValueAsync().ContinueWith(task=>
//     {
//         keysnapshot = task.Result;  
        
//     });

//    foreach (DataSnapshot child in keysnapshot.Children){
//             key = child.Key.ToString();
//         await GetProblem();
//         await GetAnswer();
//             Debug.Log(child.Key.ToString());
//         }

// }


// public async Task GetProblem(){
//       await  dbReference.Child("words").Child(key).Child("problem").GetValueAsync().ContinueWith(task=>
//     {
//         DataSnapshot snapshot = task.Result;
//             problems.Add(snapshot.Value.ToString());
      
//         Debug.Log(snapshot.Value.ToString());
//     });
//     }

// public async Task GetAnswer(){
//     await  dbReference.Child("words").Child(key).Child("answer").GetValueAsync().ContinueWith(task=>
//     {
//         DataSnapshot snapshot = task.Result;
//             answers.Add(snapshot.Value.ToString());
      
//         Debug.Log(snapshot.Value.ToString());
//     });
//     }

}
