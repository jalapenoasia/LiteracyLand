using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Firebase;
using Firebase.Database;
using TMPro;
using System.Threading.Tasks;

public class DeckHandler : MonoBehaviour
{

    public TextMeshProUGUI deckName;
    public TextMeshProUGUI word;
    public TextMeshProUGUI def;
    public GameObject addWord;
    public GameObject addWordScreen;
    public GameObject HSHandler;
    private DatabaseReference dbReference;
    public List<string> words;
    public List<string> defs;
    public string key;
    private DataSnapshot psnapshot;
    private DataSnapshot asnapshot;
    public int n;
    public GameObject Next;
    public GameObject Prev;
    private DataSnapshot keysnapshot;
    public List<string> keys;
    public GameObject play;
    public GameObject teacherplay;
    public int ln;
    public TMP_InputField problem;
    public TMP_InputField answer;
    public int gn; //getnumber

    // Start is called before the first frame update
   public async void Start()
    {

        addWordScreen.SetActive(false);
        dbReference = FirebaseDatabase.DefaultInstance.RootReference;
        HSHandler = GameObject.Find("HSManager");
    if(HSHandler.GetComponent<ClassCodeManager>().teacher == true){
        teacherplay.SetActive(true);
        play.SetActive(false);
            addWord.SetActive(true);
        } else {
            addWord.SetActive(false);
            teacherplay.SetActive(false);
        play.SetActive(true);
        }
        await GetKeys();
          key = keys[n];
          deckName.text = HSHandler.GetComponent<ClassCodeManager>().deckName;

          for(int i = 0; i < defs.Count; i++){
            Debug.Log("getting cc data");
        HSHandler.GetComponent<ClassCodeManager>().answers.Add(defs[ln]);
        HSHandler.GetComponent<ClassCodeManager>().problems.Add(words[ln]);
        ln++;
        Debug.Log("got cc data");
    
    }
        }

    // Update is called once per frame
    void Update()
    {
        word.text = words[n];
        def.text = defs[n];
          key = keys[n];
      

        if(n == 0){
        Prev.SetActive(false);
        }else{Prev.SetActive(true);}

        if(n < words.Count && n != words.Count - 1){
            Next.SetActive(true);
        } else if (n == words.Count - 1){
            Next.SetActive(false);
        } else {Next.SetActive(false);}
    }
    
public async Task GetKeys()
    {Debug.Log("GetStarted");
         await dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Child("words").GetValueAsync().ContinueWith(task=>
          {
            keysnapshot = task.Result; 
         });

          foreach (DataSnapshot child in keysnapshot.Children){
            keys.Add(child.Key.ToString());
            Debug.Log(child.Key.ToString());
            await GetProblem();
        await GetAnswer();
        gn++;
        Debug.Log("Continuing");
        }
    }

public async Task GetProblem()
    { Debug.Log("GetStarted");
    await  dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Child("words").Child(keys[gn]).Child("problem").GetValueAsync().ContinueWith(task=>
          {
            psnapshot = task.Result;  
            words.Add(psnapshot.Value.ToString());
           Debug.Log("Got Problem");
         }); 

   
           

    }

    public async Task GetAnswer()
    { Debug.Log("GetStarted");
    await  dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Child("words").Child(keys[gn]).Child("answer").GetValueAsync().ContinueWith(task=>
          {
            asnapshot = task.Result; 
            defs.Add(asnapshot.Value.ToString());
            Debug.Log("Got Answer");
           
         }); 


            
  
    }

    public void next(){
        n += 1;
    }
    public void prev(){
        n -= 1;
    }

    public void OpenAddWord(){
        addWordScreen.SetActive(true);
    }

    public void CloseAddWord(){
        addWordScreen.SetActive(false);
    }

    public void addNewWord(){
        if(word.text == "add problem" && def.text == "add answer"){
            Debug.Log("new word added");
            Word newWord = new Word(problem.text, answer.text);
        string json = JsonUtility.ToJson(newWord);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Child("words").Child(keys[n]).SetRawJsonValueAsync(json);
        words[0] = problem.text;
        defs[0] = answer.text;
        HSHandler.GetComponent<ClassCodeManager>().answers.Add(answer.text);
        HSHandler.GetComponent<ClassCodeManager>().problems.Add(problem.text);
addWordScreen.SetActive(false);
    
        } else{
        Word newWord = new Word(problem.text, answer.text);
        string json = JsonUtility.ToJson(newWord);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Child("words").Push().SetRawJsonValueAsync(json);
        words.Add(problem.text);
        defs.Add(answer.text);
        HSHandler.GetComponent<ClassCodeManager>().answers.Add(answer.text);
        HSHandler.GetComponent<ClassCodeManager>().problems.Add(problem.text);
        addWordScreen.SetActive(false);
        }
    }
    
}
