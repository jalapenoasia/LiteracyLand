using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Firebase;
using Firebase.Database;
using System.Threading.Tasks;
using UnityEngine.UI;

public class ClassWorldManager : MonoBehaviour
{
    public TextMeshProUGUI name;
    public TextMeshProUGUI code; 
    public TextMeshProUGUI XP;
    public GameObject HSHandler;
    private DatabaseReference dbReference;
    private DataSnapshot snapshot;
    public List<TextMeshProUGUI> decks;
    public TMP_InputField input;
    public List<string> keys;
    public string key;
    private DataSnapshot keysnapshot;
    public int n;
    public GameObject DeckScreen;
    public GameObject AddDeck;
    private DataSnapshot xpsnapshot;
    public GameObject addDeckButton;
    public List<string> deckNames;


    public async void Start(){
        
        DeckScreen.SetActive(false);
        AddDeck.SetActive(false);
           dbReference = FirebaseDatabase.DefaultInstance.RootReference;
        HSHandler = GameObject.Find("HSManager");
        
   name.text = HSHandler.GetComponent<ClassCodeManager>().name;
        code.text = "classcode: "+ HSHandler.GetComponent<ClassCodeManager>().code;
     await GetData();
   if(HSHandler.GetComponent<ClassCodeManager>().teacher == false){  XP.text = "XP: " + xpsnapshot.Value.ToString();}
     await GetKeys();
     await GetDeckName();
    }
 
public async Task GetData()
    { Debug.Log("GetStarted");
       await    dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("name").Child(HSHandler.GetComponent<ClassCodeManager>().name).Child("xp").GetValueAsync().ContinueWith(task=>
          {
           xpsnapshot = task.Result;  
         });
    }
public async Task GetKeys()
    {Debug.Log("GetStarted");
         await dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").GetValueAsync().ContinueWith(task=>
          {
            keysnapshot = task.Result; 
         });

          foreach (DataSnapshot child in keysnapshot.Children){
            keys.Add(child.Key.ToString());
            key = child.Key.ToString();
            decks[n].GetComponent<deckClicked>().key = key;
        await GetDeckName();
            Debug.Log(child.Key.ToString());
        }
    }

    public async Task GetDeckName(){
        

        Debug.Log("getting name");
      await  dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(key).Child("DeckName").LimitToFirst(1).GetValueAsync().ContinueWith(task=>
    {
 snapshot = task.Result;
        foreach(DataSnapshot child in snapshot.Children){
            deckNames.Add(child.Key.ToString());
             Debug.Log("GotName1");
            //    decks[n].text = deckNames[n];
                Debug.Log("GotName2");
                Debug.Log(child.Key.ToString()); 
                 Debug.Log("GotName3");
                 n++;
                 Debug.Log("GotName4");
        }
       

         
 
        
       
    });
    }
    public void createDeck(){
Deck newDeck = new Deck(input.text);
        string json = JsonUtility.ToJson(newDeck);
Word newWord = new Word("add problem", "add answer");
        string wordjson = JsonUtility.ToJson(newWord);
        string pushkey = dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Push().Key; 
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(pushkey).SetRawJsonValueAsync(json);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(pushkey).Child("DeckName").Child(input.text).Child("words").Push().SetRawJsonValueAsync(wordjson);
        deckNames.Add(input.text);
        decks[n].text = input.text;
        decks[n].GetComponent<deckClicked>().key = pushkey;
        n++;
    }
   

    public void openDeckScreen(){
        DeckScreen.SetActive(true);
        for(int i = 0; i <= deckNames.Count; i++){
            decks[i].text = deckNames[i];
        }
        if(HSHandler.GetComponent<ClassCodeManager>().teacher == true){
            addDeckButton.SetActive(true);
        } else {
            addDeckButton.SetActive(false);
        }
    }

    public void closeDeckScreen(){
        DeckScreen.SetActive(false);
    }

    public void openAddDeck(){
        AddDeck.SetActive(true);
    }

    public void closeAddDeck(){
        AddDeck.SetActive(false);
    }
}
