using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Firebase;
using Firebase.Database;



public class ClickedObjects : MonoBehaviour
{
    public static ClickedObjects instance;
   public List<string> possibleAnswers;
    public int xp;
   public GameObject HSHandler;
   private DatabaseReference dbReference;
   private float lerpStart;
   private float lerpDuration;
   private bool lerpNow;
   public GameObject wrong;
   public GameObject bushes;


void Start(){
    dbReference = FirebaseDatabase.DefaultInstance.RootReference;
    HSHandler = GameObject.Find("HSManager");
    if(GameObject.Find("bushes") != null){
            bushes = GameObject.Find("bushes");
        }
    lerpDuration = 3f;
}
   public void clicked(){

    if(gameObject.GetComponent<TextMeshProUGUI>().text == RegionManager.answer && RegionManager.an + 2 < RegionManager.answerCount){

RegionManager.an++;
        RegionManager.n++;
xp += 1;
Debug.Log(xp.ToString());

        XP updateXP = new XP(xp);
        string json = JsonUtility.ToJson(updateXP);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("name").Child(HSHandler.GetComponent<ClassCodeManager>().name).SetRawJsonValueAsync(json);

       
       Debug.Log("correct! +1, move foward");
       Debug.Log(RegionManager.answer);

       if(bushes != null){
        bushes.GetComponent<bushes>().resetBushes();}
       

        
    } else if(gameObject.GetComponent<TextMeshProUGUI>().text == RegionManager.answer && RegionManager.an + 2 >= RegionManager.answerCount && RegionManager.n  != RegionManager.answerCount){
 Debug.Log("correct! +1, no foward");
 RegionManager.n++;
       xp += 1;
Debug.Log(xp.ToString());
    
       XP updateXP = new XP(xp);
        string json = JsonUtility.ToJson(updateXP);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("name").Child(HSHandler.GetComponent<ClassCodeManager>().name).SetRawJsonValueAsync(json);
if(bushes != null){
         bushes.GetComponent<bushes>().resetBushes();}
    }else{
        Debug.Log("incorrect");
        xp-= 1;
    }
   }
 void Update(){
    if(lerpNow == true){
        
        float progress = Time.time - lerpStart;
        Color tmp = gameObject.GetComponent<SpriteRenderer>().material.color;
        tmp.a = 0;
        gameObject.GetComponent<SpriteRenderer>().material.color = Color.Lerp(gameObject.GetComponent<SpriteRenderer>().material.color, tmp, progress/lerpDuration);
 Destroy(gameObject);
        if(lerpDuration < progress){
            lerpNow = false;
           
        }

    }

    if(RegionManager.n  == RegionManager.answerCount){
       RegionManager.celebrate = true;
    } 
 }
   public void colorLerp(){

        lerpNow = true;
        lerpStart = Time.time;
   }

  
}
