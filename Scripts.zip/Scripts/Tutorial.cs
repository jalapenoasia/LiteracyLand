using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Tutorial : MonoBehaviour
{
   public List<string> tut;
   public int n;
   public TextMeshProUGUI text;
   public GameObject tuts;

   void Start(){
    text.text = tut[n];
   }
public void clicked(){
n++;
text.text = tut[n];

}

void Update(){
    if(n == tut.Count){
        tuts.SetActive(false);
    }
}



}
