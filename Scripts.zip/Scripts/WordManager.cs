using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Firebase;
using Firebase.Database;

public class WordManager : MonoBehaviour
{
    public TMP_InputField problem;
    public TMP_InputField answer;
    private DatabaseReference dbReference;
    public GameObject HSHandler;
    private DataSnapshot keysnapshot;
   
    public TextMeshProUGUI deckName;


    void Start(){
            dbReference = FirebaseDatabase.DefaultInstance.RootReference;
            HSHandler = GameObject.Find("HSManager");
            deckName.text = HSHandler.GetComponent<ClassCodeManager>().deckName;
    }

    

    public void addWord(){
    
        Word newWord = new Word(problem.text, answer.text);
        string json = JsonUtility.ToJson(newWord);
        dbReference.Child("classcode").Child(HSHandler.GetComponent<ClassCodeManager>().code).Child("decks").Child(HSHandler.GetComponent<ClassCodeManager>().key).Child("DeckName").Child(HSHandler.GetComponent<ClassCodeManager>().deckName).Push().SetRawJsonValueAsync(json);

    }
}
