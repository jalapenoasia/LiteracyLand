using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreeHandler : MonoBehaviour
{
    public static int growthCount;
    public static int grownTree;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
      if(growthCount == 10)
      {
        grownTree+=1;
        //save to database
        growthCount = 0;
        //Save to database
      }  
    }
}
