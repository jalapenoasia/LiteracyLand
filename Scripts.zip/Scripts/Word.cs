using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Word : MonoBehaviour
{
  public string problem;
  public string answer;

  public Word(string problem, string answer){
        this.problem = problem;
        this.answer = answer;
  }
}
