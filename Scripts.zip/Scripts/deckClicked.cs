using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;

public class deckClicked : MonoBehaviour
{
    public GameObject HSHandler;
    public string key;


    void Start(){
         HSHandler = GameObject.Find("HSManager");
    }
   public void clicked(){
     HSHandler.GetComponent<ClassCodeManager>().deckName = gameObject.GetComponent<TextMeshProUGUI>().text ;
     HSHandler.GetComponent<ClassCodeManager>().key = key; 
   }

   void Update(){
    if(gameObject.GetComponent<TextMeshProUGUI>().text == "+"){
      gameObject.GetComponent<EventTrigger>().enabled = false;
    } else{
      gameObject.GetComponent<EventTrigger>().enabled = true;
    }
   }
}
