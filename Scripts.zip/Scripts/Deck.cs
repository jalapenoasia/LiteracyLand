using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deck : MonoBehaviour
{
   public string DeckName;

  public Deck(string DeckName){
        this.DeckName = DeckName;
        
  }
}
